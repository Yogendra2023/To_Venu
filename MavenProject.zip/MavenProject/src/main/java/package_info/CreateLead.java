package package_info;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CreateLead extends ProjectSpecificMethods {
	@BeforeTest
	public void setData() {
		excelfilename="TC001";
	}
	@Test(dataProvider = "sendData")
	public void runCreateLead(String username, String password,String cname, String fname, String lname, String source) {
		driver.findElement(By.id("username")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		Select dropdown = new Select(driver.findElement(By.id("createLeadForm_dataSourceId")));
		dropdown.selectByVisibleText(source);
		driver.findElement(By.name("submitButton")).click();
	}

	
}
