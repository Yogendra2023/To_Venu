package package_info;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWindows {
public static void main(String[] args) {
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://leafground.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
	driver.findElement(By.xpath("//ul[@class='layout-menu']/li[2]")).click();
	driver.findElement(By.xpath("//span[text()='Window']/..")).click();
	
	/* driver.findElement(By.xpath("//span[text()='Open']/..")).click();
	
	Set<String> set = driver.getWindowHandles();
	for (String eachHandle : set) {
		driver.switchTo().window(eachHandle);
		if(driver.getCurrentUrl().equals("https://leafground.com/dashboard.xhtml")) {
			break;
		}
	} */
	
	// Store the current window handle
	String winHandleBefore = driver.getWindowHandle();
	
	// Perform the click operation that opens new window
	driver.findElement(By.xpath("//span[text()='Open']/..")).click();
	// Switch to new window opened
	for(String winHandle : driver.getWindowHandles()){
	    driver.switchTo().window(winHandle);
	}

	// Perform the actions on new window
	System.out.println(driver.getTitle());
	// Close the new window, if that window no more required
	driver.close();

	// Switch back to original browser (first window)
	driver.switchTo().window(winHandleBefore);
	
	
	
}
}
